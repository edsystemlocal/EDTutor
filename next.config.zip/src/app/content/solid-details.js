export default function SolidDetails() {
    return (
      <div className="flex flex-col w-full text-gray-700">
        Solid Details
      </div>
    );
}