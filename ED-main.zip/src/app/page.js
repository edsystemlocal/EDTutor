import React from 'react'
import Login from './login/page'

const page = () => {
  return (
    <div>
      <Login/>
    </div>
  )
}

export default page