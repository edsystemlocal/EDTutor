const companyDetails = {
    name: "ASTRETECH SOLUTIONS AND TECHNOLOGY",
    contactNumber: "+1-234-567-890",
    email: "support@astretech.com",
    tagline: "Learn and draw different types of geometric figures effortlessly!",
    updates: "Stay tuned for more updates!",
  };
  
  export default companyDetails;
  